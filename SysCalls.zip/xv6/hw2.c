#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"
#include "syscall.h"



int main(void){

int fd;
int stdout = 1;

printf(stdout, "Liz aka Frankie Ruttenbur\n"); //prints out my name

fd=open("tom.txt", O_CREATE|O_RDWR); //tries to open tom.txt, creates it if it isn't there

write(fd,"1,2,3,4", 8); //writes to the file
close(fd);
exit();

}

